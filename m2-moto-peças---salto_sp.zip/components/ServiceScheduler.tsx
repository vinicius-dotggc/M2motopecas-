import React, { useState } from 'react';
import { Calendar, Bike, ChevronRight, Wrench } from 'lucide-react';
import { WHATSAPP_NUMBER } from '../constants';

export const ServiceScheduler: React.FC = () => {
  const [moto, setMoto] = useState('');
  const [servico, setServico] = useState('');

  const handleSchedule = () => {
    if (!moto || !servico) {
      alert("Por favor, preencha o modelo da moto e o serviço desejado.");
      return;
    }
    const message = encodeURIComponent(`Olá M2! Gostaria de agendar uma manutenção:\n\nMoto: ${moto}\nServiço: ${servico}\n\nQual o próximo horário disponível?`);
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank');
  };

  return (
    <div className="bg-zinc-800/40 border border-white/10 rounded-[32px] p-8 md:p-12 backdrop-blur-xl shadow-2xl">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-red-600 rounded-2xl shadow-lg shadow-red-600/30">
          <Calendar className="text-white" size={24} />
        </div>
        <div>
          <h3 className="text-2xl font-oswald font-bold text-white uppercase tracking-tighter">Agendamento Expresso</h3>
          <p className="text-xs text-gray-400 uppercase tracking-widest">Reserve seu horário na oficina</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Sua Motocicleta</label>
          <div className="relative">
            <Bike className="absolute left-4 top-1/2 -translate-y-1/2 text-red-500" size={18} />
            <input 
              type="text" 
              placeholder="Ex: Honda CB 500X"
              value={moto}
              onChange={(e) => setMoto(e.target.value)}
              className="w-full bg-zinc-900 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white text-sm focus:border-red-600 outline-none transition-all placeholder:text-gray-600"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Serviço Desejado</label>
          <div className="relative">
            <Wrench className="absolute left-4 top-1/2 -translate-y-1/2 text-red-500" size={18} />
            <select 
              value={servico}
              onChange={(e) => setServico(e.target.value)}
              className="w-full bg-zinc-900 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white text-sm focus:border-red-600 outline-none transition-all appearance-none cursor-pointer"
            >
              <option value="" className="bg-zinc-900">Selecione o serviço...</option>
              <option value="Troca de Óleo" className="bg-zinc-900">Troca de Óleo</option>
              <option value="Revisão Periódica" className="bg-zinc-900">Revisão Periódica</option>
              <option value="Relação/Transmissão" className="bg-zinc-900">Relação/Transmissão</option>
              <option value="Troca de Pneus" className="bg-zinc-900">Troca de Pneus</option>
              <option value="Sistema de Freios" className="bg-zinc-900">Sistema de Freios</option>
              <option value="Diagnóstico Injeção" className="bg-zinc-900">Diagnóstico Injeção</option>
            </select>
          </div>
        </div>
      </div>

      <button 
        onClick={handleSchedule}
        className="w-full mt-8 bg-red-600 hover:bg-red-500 text-white font-bold py-5 rounded-2xl flex items-center justify-center gap-3 transition-all transform hover:scale-[1.01] shadow-xl group"
      >
        SOLICITAR HORÁRIO DISPONÍVEL
        <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
      </button>
    </div>
  );
};