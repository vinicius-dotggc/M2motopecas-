import React, { useState } from 'react';
import { X, CheckCircle2, Bike, Info, Image as ImageIcon, MessageCircle, Star } from 'lucide-react';
import { ProductItem } from '../types';
import { WhatsAppButton } from './WhatsAppButton';
import { ReviewSection } from './ReviewSection';
import { TESTIMONIALS } from '../constants';

interface ProductDetailModalProps {
  product: ProductItem;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose }) => {
  const [activeTab, setActiveTab] = useState<'info' | 'gallery' | 'reviews'>('info');
  const [showReviews, setShowReviews] = useState(false);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="relative w-full max-w-4xl max-h-[90vh] glass-card rounded-[32px] md:rounded-[40px] border-futuristic overflow-hidden flex flex-col shadow-[0_0_100px_rgba(220,38,38,0.2)]">
        
        {/* Close Button - More prominent on mobile */}
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 md:top-6 md:right-6 z-30 p-2 md:p-3 bg-black/50 hover:bg-red-600 rounded-xl md:rounded-2xl transition-all text-white group border border-white/10"
        >
          <X size={20} className="group-hover:scale-110 transition-transform md:w-6 md:h-6" />
        </button>

        <div className="flex flex-col lg:flex-row h-full overflow-y-auto lg:overflow-hidden">
          
          {/* Left Side: Visuals */}
          <div className="lg:w-1/2 h-[250px] sm:h-[350px] lg:h-auto bg-zinc-950 relative overflow-hidden shrink-0">
            <img 
              src={product.image || 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&q=80&w=800'} 
              alt={product.name} 
              className="w-full h-full object-cover opacity-80"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent"></div>
            <div className="absolute bottom-6 left-6 right-6 md:bottom-8 md:left-8 md:right-8">
              <span className="bg-red-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-widest mb-2 inline-block">
                {product.category}
              </span>
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-oswald font-bold text-white uppercase leading-tight tracking-tighter">
                {product.name}
              </h2>
            </div>
          </div>

          {/* Right Side: Content Area */}
          <div className="lg:w-1/2 flex flex-col h-full bg-zinc-900/50">
            
            {/* Tabs Navigation - Refined for mobile (horizontal scroll) */}
            <div className="flex border-b border-white/5 px-6 md:px-8 pt-6 md:pt-8 gap-5 md:gap-8 overflow-x-auto scrollbar-hide shrink-0">
              {[
                { id: 'info', label: 'Especificações', icon: Info },
                { id: 'gallery', label: 'Galeria', icon: ImageIcon },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 pb-4 text-[10px] font-bold uppercase tracking-widest transition-all relative whitespace-nowrap shrink-0 ${
                    activeTab === tab.id ? 'text-red-500' : 'text-zinc-500 hover:text-white'
                  }`}
                >
                  <tab.icon size={14} />
                  {tab.label}
                  {activeTab === tab.id && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600 shadow-[0_0_10px_#dc2626]" />
                  )}
                </button>
              ))}
              <button
                onClick={() => setShowReviews(true)}
                className="flex items-center gap-2 pb-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500 hover:text-red-500 transition-all whitespace-nowrap shrink-0"
              >
                <Star size={14} />
                Avaliações
              </button>
            </div>

            {/* Tab Content */}
            <div className="flex-grow overflow-y-auto p-6 md:p-8 custom-scrollbar">
              {activeTab === 'info' && (
                <div className="space-y-6 md:space-y-8 animate-in slide-in-from-right duration-500">
                  <div>
                    <h4 className="text-[10px] font-bold text-red-500 uppercase tracking-[0.3em] mb-3">Sobre o Produto</h4>
                    <p className="text-gray-400 text-sm font-light leading-relaxed">{product.description}</p>
                  </div>

                  {product.specs && (
                    <div>
                      <h4 className="text-[10px] font-bold text-red-500 uppercase tracking-[0.3em] mb-3">Ficha Técnica</h4>
                      <div className="grid grid-cols-1 gap-2 md:gap-3">
                        {product.specs.map((spec, i) => (
                          <div key={i} className="flex items-center gap-3 bg-white/5 p-3 md:p-4 rounded-xl md:rounded-2xl border border-white/5">
                            <CheckCircle2 size={16} className="text-red-600 shrink-0" />
                            <span className="text-xs text-gray-300">{spec}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {product.compatibility && (
                    <div>
                      <h4 className="text-[10px] font-bold text-red-500 uppercase tracking-[0.3em] mb-3">Compatibilidade</h4>
                      <div className="flex flex-wrap gap-2">
                        {product.compatibility.map((item, i) => (
                          <div key={i} className="flex items-center gap-2 bg-zinc-950 px-3 py-1.5 rounded-lg border border-white/5">
                            <Bike size={12} className="text-red-600" />
                            <span className="text-[9px] text-gray-400 uppercase font-bold tracking-widest">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'gallery' && (
                <div className="animate-in slide-in-from-right duration-500">
                  <div className="grid grid-cols-2 gap-3 md:gap-4">
                    {(product.gallery && product.gallery.length > 0) ? product.gallery.map((img, i) => (
                      <div key={i} className="aspect-square rounded-xl md:rounded-2xl overflow-hidden border border-white/5 hover:border-red-600/50 transition-all cursor-zoom-in">
                        <img src={img} className="w-full h-full object-cover" alt={`Gallery ${i}`} />
                      </div>
                    )) : (
                      <div className="col-span-2 py-16 md:py-20 text-center opacity-20">
                        <ImageIcon size={40} className="mx-auto mb-4" />
                        <p className="text-[10px] uppercase tracking-widest">Nenhuma imagem adicional</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Footer Buttons */}
            <div className="p-6 md:p-8 border-t border-white/5 bg-black/30 flex flex-col sm:flex-row gap-3 md:gap-4">
              <WhatsAppButton 
                itemTitle={product.name} 
                label="SOLICITAR PREÇO" 
                className="flex-grow py-4 md:py-5 text-[10px] md:text-[11px] tracking-[0.2em] rounded-xl md:rounded-2xl" 
              />
              <button 
                onClick={onClose}
                className="px-6 py-4 md:py-5 rounded-xl md:rounded-2xl border border-white/10 text-[10px] md:text-[11px] font-bold uppercase tracking-[0.2em] text-gray-500 hover:text-white transition-all sm:w-auto"
              >
                Voltar
              </button>
            </div>
          </div>
        </div>
      </div>

      {showReviews && (
        <ReviewSection 
          productName={product.name} 
          reviews={TESTIMONIALS} 
          onClose={() => setShowReviews(false)} 
        />
      )}
    </div>
  );
};