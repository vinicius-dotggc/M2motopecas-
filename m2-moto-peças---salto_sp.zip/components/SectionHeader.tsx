
import React from 'react';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({ title, subtitle }) => (
  <div className="mb-12 text-center">
    <h2 className="text-4xl md:text-5xl font-oswald font-bold uppercase tracking-tighter text-red-600 text-glow-red">
      {title}
    </h2>
    {subtitle && (
      <p className="mt-4 text-gray-400 max-w-2xl mx-auto text-lg">
        {subtitle}
      </p>
    )}
    <div className="mt-4 h-1 w-24 bg-red-700 mx-auto rounded-full shadow-[0_0_8px_#dc2626]"></div>
  </div>
);
