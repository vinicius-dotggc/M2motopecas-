
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { ImageSize, AspectRatio } from "../types";

// Helper for encoding/decoding as requested in instructions
export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const geminiService = {
  // 1. Text Search Grounding (Gemini 3 Flash)
  async searchInfo(query: string) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    return {
      text: response.text || "",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => chunk.web).filter(Boolean) || []
    };
  },

  // 2. Maps Grounding (Gemini 2.5 Flash)
  async findPlaces(query: string, lat?: number, lng?: number) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const toolConfig = lat && lng ? {
      retrievalConfig: {
        latLng: { latitude: lat, longitude: lng }
      }
    } : undefined;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: query,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig
      },
    });
    return {
      text: response.text || "",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => chunk.maps).filter(Boolean) || []
    };
  },

  // 3. Image Generation (Gemini 3 Pro Image)
  async generateImage(prompt: string, size: ImageSize, ratio: AspectRatio) {
    // Creating fresh instance as per guidelines for latest API key usage
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio: ratio as any,
          imageSize: size as any
        }
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  },

  // 4. Video Generation (Veo 3.1 Fast)
  async generateVideo(prompt: string, imageBase64?: string, isPortrait?: boolean) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const config = {
      numberOfVideos: 1,
      resolution: '720p' as const,
      aspectRatio: isPortrait ? '9:16' as const : '16:9' as const
    };

    // Clean base64 data if it contains the data: URL prefix
    const cleanBase64 = imageBase64?.includes(',') ? imageBase64.split(',')[1] : imageBase64;

    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt,
      ...(cleanBase64 ? { image: { imageBytes: cleanBase64, mimeType: 'image/png' } } : {}),
      config
    });

    while (!operation.done) {
      // Per guidelines: Recommendation for polling interval is 10s
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    // CRITICAL: Must append API key when fetching from the download link
    return `${downloadLink}&key=${process.env.API_KEY}`;
  }
};
