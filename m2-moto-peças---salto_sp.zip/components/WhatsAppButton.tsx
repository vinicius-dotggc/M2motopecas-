
import React from 'react';
import { MessageCircle } from 'lucide-react';
import { WHATSAPP_NUMBER } from '../constants';

interface WhatsAppButtonProps {
  label: string;
  itemTitle: string;
  className?: string;
}

export const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({ label, itemTitle, className }) => {
  const handleClick = () => {
    const message = encodeURIComponent(`Olá! Gostaria de consultar o preço e disponibilidade de: ${itemTitle}`);
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      className={`flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white font-bold py-3 px-6 rounded-lg transition-all transform hover:scale-105 active:scale-95 shadow-lg border border-red-400/20 ${className}`}
    >
      <MessageCircle size={20} />
      {label}
    </button>
  );
};
