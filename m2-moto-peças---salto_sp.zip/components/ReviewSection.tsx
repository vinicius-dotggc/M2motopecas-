
import React, { useState } from 'react';
import { Star, Send, X, User } from 'lucide-react';
import { Review } from '../types';

interface ReviewSectionProps {
  reviews: Review[];
  productName: string;
  onClose: () => void;
}

export const ReviewSection: React.FC<ReviewSectionProps> = ({ reviews: initialReviews, productName, onClose }) => {
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [newReview, setNewReview] = useState({ userName: '', rating: 5, comment: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.userName || !newReview.comment) return;

    const review: Review = {
      id: Math.random().toString(36).substr(2, 9),
      userName: newReview.userName,
      rating: newReview.rating,
      comment: newReview.comment,
      date: new Date().toLocaleDateString('pt-BR'),
    };

    setReviews([review, ...reviews]);
    setNewReview({ userName: '', rating: 5, comment: '' });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-2xl max-h-[90vh] glass-card rounded-[40px] border-futuristic overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-8 border-b border-white/5 flex items-center justify-between bg-red-600/10">
          <div>
            <h3 className="text-2xl font-oswald font-bold uppercase tracking-tighter text-white">Avaliações</h3>
            <p className="text-sm text-red-500 font-bold uppercase tracking-widest">{productName}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white">
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-grow overflow-y-auto p-8 space-y-8 custom-scrollbar">
          {/* Review List */}
          <div className="space-y-6">
            {reviews.length === 0 ? (
              <div className="text-center py-10 opacity-30">
                <Star size={48} className="mx-auto mb-4" />
                <p className="text-sm uppercase tracking-widest">Nenhuma avaliação ainda</p>
              </div>
            ) : (
              reviews.map((r) => (
                <div key={r.id} className="p-6 rounded-3xl bg-white/5 border border-white/5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-red-600/20 flex items-center justify-center text-red-500">
                        <User size={20} />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white">{r.userName}</p>
                        <p className="text-[10px] text-gray-500 uppercase tracking-widest">{r.date}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={12} className={i < r.rating ? 'text-red-500 fill-red-500' : 'text-zinc-800'} />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-gray-400 font-light leading-relaxed">{r.comment}</p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Form */}
        <div className="p-8 bg-zinc-950 border-t border-white/5">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Seu Nome"
                value={newReview.userName}
                onChange={(e) => setNewReview({ ...newReview, userName: e.target.value })}
                className="bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-red-600 outline-none transition-all"
              />
              <div className="flex items-center justify-center gap-2 bg-black/50 border border-white/10 rounded-xl px-4">
                <span className="text-[10px] text-gray-500 uppercase tracking-widest mr-2">Nota:</span>
                {[1, 2, 3, 4, 5].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setNewReview({ ...newReview, rating: s })}
                    className="transition-transform active:scale-125"
                  >
                    <Star
                      size={18}
                      className={s <= newReview.rating ? 'text-red-500 fill-red-500' : 'text-zinc-800'}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div className="relative">
              <textarea
                placeholder="Escreva seu comentário..."
                value={newReview.comment}
                onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 pr-12 text-sm text-white focus:border-red-600 outline-none transition-all resize-none h-20"
              />
              <button
                type="submit"
                className="absolute bottom-4 right-4 p-2 bg-red-600 text-white rounded-lg hover:bg-red-500 transition-all active:scale-95 shadow-lg shadow-red-600/20"
              >
                <Send size={18} />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
