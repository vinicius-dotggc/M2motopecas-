
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { Mic, MicOff, Loader2, Volume2, X } from 'lucide-react';
import { encode, decode, decodeAudioData } from '../services/gemini';

export const LiveMechanic: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const startConversation = async () => {
    setIsConnecting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsConnected(true);
            setIsConnecting(false);
            
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (event) => {
              const inputData = event.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);
          },
          onmessage: async (message) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              setIsSpeaking(true);
              const ctx = outputAudioContextRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsSpeaking(false);
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => console.error("Live Error", e),
          onclose: () => setIsConnected(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } },
          systemInstruction: 'Você é um mecânico especialista de motos da M2 Moto Peças em Salto/SP. Ajude os clientes com dúvidas técnicas sobre peças, marcas de óleo (Motul, Castrol) e pneus (Pirelli, Metzeler). Seja amigável, técnico e use gírias de motociclista. Informe que a loja fica na Av. 9 de Julho, 1893.'
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setIsConnecting(false);
    }
  };

  const stopConversation = () => {
    if (sessionRef.current) {
      try { (sessionRef.current as any).close(); } catch {}
    }
    audioContextRef.current?.close();
    outputAudioContextRef.current?.close();
    setIsConnected(false);
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => { setIsOpen(true); startConversation(); }}
        className="fixed bottom-6 right-6 z-50 bg-red-600 hover:bg-red-500 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform glow-red group"
      >
        <Mic size={24} className="group-hover:animate-pulse" />
        <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-zinc-900 text-white px-3 py-1 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none border border-zinc-800 font-bold uppercase tracking-widest text-[10px]">
          IA Mecânico M2
        </span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-80 bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 backdrop-blur-md bg-opacity-90">
      <div className="bg-red-600 p-4 flex items-center justify-between shadow-[0_4px_10px_rgba(220,38,38,0.3)]">
        <h3 className="text-white font-oswald font-bold flex items-center gap-2 uppercase tracking-tighter">
          <Volume2 size={18} /> Mecânico em Tempo Real
        </h3>
        <button onClick={stopConversation} className="text-white hover:bg-red-500 p-1 rounded transition-colors">
          <X size={20} />
        </button>
      </div>

      <div className="p-8 flex flex-col items-center justify-center space-y-6">
        <div className={`w-32 h-32 rounded-full border-2 flex items-center justify-center transition-all duration-500 ${
          isConnected ? (isSpeaking ? 'border-red-500 scale-110 shadow-[0_0_40px_rgba(220,38,38,0.5)]' : 'border-red-600/30') : 'border-zinc-800'
        }`}>
          {isConnecting ? (
            <Loader2 size={48} className="animate-spin text-red-500" />
          ) : isConnected ? (
            <div className="relative">
              <Mic size={48} className={isSpeaking ? 'text-red-500' : 'text-red-600/50'} />
              {isSpeaking && (
                <div className="absolute -inset-4 border-2 border-red-500/30 rounded-full animate-ping"></div>
              )}
            </div>
          ) : (
            <MicOff size={48} className="text-zinc-600" />
          )}
        </div>

        <div className="text-center">
          <p className="font-oswald uppercase tracking-widest text-white mb-1">
            {isConnecting ? 'CONECTANDO...' : isConnected ? 'PODE FALAR!' : 'ERRO NA CONEXÃO'}
          </p>
          <p className="text-xs text-gray-400 font-light">
            {isSpeaking ? 'Processando voz...' : isConnected ? 'Ouvindo o motor...' : 'Tente novamente.'}
          </p>
        </div>

        <button 
          onClick={stopConversation}
          className="w-full bg-zinc-800 hover:bg-zinc-700 text-white py-3 rounded-xl text-xs font-bold uppercase tracking-widest border border-zinc-700 transition-colors"
        >
          Desconectar
        </button>
      </div>
    </div>
  );
};
