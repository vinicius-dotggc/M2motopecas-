import React from 'react';
import { Home, Wrench, Package, Phone } from 'lucide-react';

interface MobileNavProps {
  activeSection: string;
}

export const MobileNav: React.FC<MobileNavProps> = ({ activeSection }) => {
  const navItems = [
    { id: 'home', label: 'Início', icon: Home },
    { id: 'servicos', label: 'Serviços', icon: Wrench },
    { id: 'produtos', label: 'Produtos', icon: Package },
    { id: 'contato', label: 'Contato', icon: Phone },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      // Compensação exata para o header superior no mobile (aprox 80px)
      const offset = 80; 
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: id === 'home' ? 0 : offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 z-[100] bg-[#050505] border-t border-white/10 h-20 md:hidden flex items-center justify-around px-2 shadow-[0_-10px_40px_rgba(0,0,0,0.9)] overflow-hidden select-none touch-none"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      onContextMenu={(e) => e.preventDefault()}
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeSection === item.id;
        
        return (
          <a
            key={item.id}
            href={`#${item.id}`}
            onClick={(e) => handleNavClick(e, item.id)}
            draggable="false"
            className="relative flex flex-col items-center justify-center flex-1 h-full gap-1 no-underline touch-none"
          >
            <div 
              draggable="false"
              className={`p-2 rounded-xl transition-colors duration-200 pointer-events-none ${
                isActive 
                  ? 'bg-red-600 text-white' 
                  : 'text-zinc-500'
              }`}
            >
              <Icon size={22} />
            </div>
            <span 
              draggable="false"
              className={`text-[9px] font-bold uppercase tracking-widest transition-colors duration-200 pointer-events-none ${
                isActive ? 'text-red-500' : 'text-zinc-600'
              }`}
            >
              {item.label}
            </span>
            {isActive && (
              <div className="absolute top-1 w-1.5 h-1.5 bg-red-600 rounded-full shadow-[0_0_10px_#dc2626]" />
            )}
          </a>
        );
      })}
    </nav>
  );
};