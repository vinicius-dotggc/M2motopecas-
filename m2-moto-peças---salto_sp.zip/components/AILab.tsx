
import React, { useState, useRef } from 'react';
import { SectionHeader } from './SectionHeader';
import { geminiService } from '../services/gemini';
import { ImageSize, AspectRatio, GroundingSource } from '../types';
import { getIcon } from '../constants';
import { Loader2, ArrowRight, Video, Sparkles, Map, Search as SearchIcon, Mic } from 'lucide-react';

// Removed redundant global Window declaration for aistudio as it is already defined in the environment as AIStudio.
// This resolves the "All declarations of 'aistudio' must have identical modifiers" and "Subsequent property declarations must have the same type" errors.

export const AILab: React.FC = () => {
  const [activeTool, setActiveTool] = useState<'image' | 'video' | 'search' | 'maps'>('image');
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [resultVideo, setResultVideo] = useState<string | null>(null);
  const [searchResult, setSearchResult] = useState<{ text: string, sources: GroundingSource[] } | null>(null);
  
  // Options
  const [imgSize, setImgSize] = useState<ImageSize>(ImageSize.S1K);
  const [imgRatio, setImgRatio] = useState<AspectRatio>(AspectRatio.R16_9);
  const [videoFile, setVideoFile] = useState<string | null>(null);

  const checkAndPromptApiKey = async () => {
    if (activeTool === 'image' || activeTool === 'video') {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await window.aistudio.openSelectKey();
      }
    }
  };

  const handleImageGen = async () => {
    if (!prompt) return;
    await checkAndPromptApiKey();
    setLoading(true);
    try {
      const url = await geminiService.generateImage(prompt, imgSize, imgRatio);
      setResultImage(url);
    } catch (e: any) {
      console.error(e);
      if (e?.message?.includes('Requested entity was not found')) {
        await window.aistudio.openSelectKey();
      } else {
        alert("Erro ao gerar imagem. Verifique se possui permissões.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVideoGen = async () => {
    if (!prompt && !videoFile) return;
    await checkAndPromptApiKey();
    setLoading(true);
    try {
      const url = await geminiService.generateVideo(prompt, videoFile || undefined, false);
      setResultVideo(url);
    } catch (e: any) {
      console.error(e);
      if (e?.message?.includes('Requested entity was not found')) {
        await window.aistudio.openSelectKey();
      } else {
        alert("Erro ao gerar vídeo. Certifique-se de usar uma chave paga se necessário.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!prompt) return;
    setLoading(true);
    try {
      const res = await geminiService.searchInfo(prompt);
      setSearchResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleMaps = async () => {
    if (!prompt) return;
    setLoading(true);
    try {
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const res = await geminiService.findPlaces(prompt, pos.coords.latitude, pos.coords.longitude);
        setSearchResult(res);
        setLoading(false);
      }, async () => {
        const res = await geminiService.findPlaces(prompt);
        setSearchResult(res);
        setLoading(false);
      });
    } catch (e) {
      console.error(e);
      setLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setVideoFile(ev.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const supportedRatios = Object.values(AspectRatio).filter(r => 
    ['1:1', '3:4', '4:3', '9:16', '16:9'].includes(r)
  );

  return (
    <section id="ai-lab" className="py-20 bg-zinc-950 border-t border-zinc-900">
      <div className="container mx-auto px-4">
        <SectionHeader 
          title="AI Lab" 
          subtitle="Visualize sua moto no futuro. Gere arte customizada e consulte nossa IA técnica especializada em M2 Moto Peças." 
        />

        <div className="flex flex-wrap justify-center gap-4 mb-10">
          {[
            { id: 'image', label: 'Arte Custom', icon: <Sparkles size={18}/> },
            { id: 'video', label: 'Visualizador de Vídeo', icon: <Video size={18}/> },
            { id: 'search', label: 'Pesquisa Técnica', icon: <SearchIcon size={18}/> },
            { id: 'maps', label: 'Rotas Inteligentes', icon: <Map size={18}/> },
          ].map(tool => (
            <button
              key={tool.id}
              onClick={() => {
                setActiveTool(tool.id as any);
                setSearchResult(null);
                setResultImage(null);
                setResultVideo(null);
              }}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all border ${
                activeTool === tool.id 
                  ? 'bg-red-600 text-white shadow-lg border-red-500' 
                  : 'bg-zinc-900 text-gray-400 hover:bg-zinc-800 border-zinc-800'
              }`}
            >
              {tool.icon}
              {tool.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div className="bg-zinc-900/80 p-8 rounded-2xl border border-zinc-800 shadow-2xl backdrop-blur-sm">
            <h3 className="text-2xl font-oswald mb-6 flex items-center gap-3 text-white">
              {activeTool === 'image' && <><Sparkles className="text-red-500" /> Crie sua Custom Bike Art</>}
              {activeTool === 'video' && <><Video className="text-red-500" /> Animador de Projetos</>}
              {activeTool === 'search' && <><SearchIcon className="text-red-500" /> Enciclopédia M2</>}
              {activeTool === 'maps' && <><Map className="text-red-500" /> Buscador de Peças M2</>}
            </h3>

            {(activeTool === 'image' || activeTool === 'video') && (
              <div className="mb-6 p-4 bg-red-950/20 border border-red-900/50 rounded-xl">
                <p className="text-xs text-red-200">
                  Para alta qualidade 4K ou vídeos, utilize uma chave de API válida. 
                </p>
              </div>
            )}

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Comando ou Pergunta</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder={
                    activeTool === 'image' ? "Ex: Uma moto super esportiva vermelha e preta no estilo cyberpunk..." :
                    activeTool === 'video' ? "Ex: Uma moto em alta velocidade por uma avenida iluminada..." :
                    activeTool === 'search' ? "Ex: Quais as vantagens de um pneu Pirelli Diablo?" :
                    "Ex: Onde fica a M2 Moto Peças em Salto?"
                  }
                  className="w-full bg-black/50 border border-zinc-800 rounded-xl p-4 text-white focus:ring-2 focus:ring-red-600 outline-none h-32 resize-none transition-all"
                />
              </div>

              {activeTool === 'image' && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Qualidade</label>
                    <select 
                      value={imgSize} 
                      onChange={(e) => setImgSize(e.target.value as ImageSize)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-white outline-none focus:border-red-600"
                    >
                      <option value={ImageSize.S1K}>1K Standard</option>
                      <option value={ImageSize.S2K}>2K High Def</option>
                      <option value={ImageSize.S4K}>4K Ultra</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Formato</label>
                    <select 
                      value={imgRatio} 
                      onChange={(e) => setImgRatio(e.target.value as AspectRatio)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-white outline-none focus:border-red-600"
                    >
                      {supportedRatios.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                </div>
              )}

              {activeTool === 'video' && (
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Imagem de Referência (Opcional)</label>
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-white text-sm file:bg-red-600 file:border-none file:px-4 file:py-1 file:rounded file:text-white file:font-bold file:mr-4 file:cursor-pointer"
                  />
                </div>
              )}

              <button
                disabled={loading}
                onClick={
                  activeTool === 'image' ? handleImageGen :
                  activeTool === 'video' ? handleVideoGen :
                  activeTool === 'search' ? handleSearch :
                  handleMaps
                }
                className="w-full bg-red-600 hover:bg-red-500 disabled:bg-zinc-800 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-3 transition-all transform hover:scale-[1.02] shadow-[0_0_15px_rgba(220,38,38,0.3)]"
              >
                {loading ? <Loader2 className="animate-spin" /> : <ArrowRight />}
                {loading ? 'Sincronizando...' : 'Processar IA'}
              </button>
            </div>
          </div>

          <div className="min-h-[400px] flex flex-col items-center justify-center bg-black/40 rounded-2xl border border-dashed border-zinc-800 p-8 overflow-hidden backdrop-blur-md">
            {!resultImage && !resultVideo && !searchResult && !loading && (
              <div className="text-center text-gray-600">
                <Sparkles size={48} className="mb-4 mx-auto opacity-20" />
                <p className="font-oswald uppercase tracking-widest text-sm">Pronto para o futuro</p>
              </div>
            )}

            {loading && (
              <div className="text-center space-y-4">
                <Loader2 size={48} className="animate-spin text-red-600 mx-auto" />
                <p className="text-red-500 font-oswald uppercase tracking-widest animate-pulse">Gerando Dados...</p>
              </div>
            )}

            {!loading && activeTool === 'image' && resultImage && (
              <div className="w-full h-full animate-in fade-in zoom-in duration-700">
                <img src={resultImage} alt="IA Art" className="rounded-lg shadow-[0_0_30px_rgba(220,38,38,0.2)] w-full object-contain max-h-[500px]" />
              </div>
            )}

            {!loading && activeTool === 'video' && resultVideo && (
              <div className="w-full h-full animate-in fade-in duration-700">
                <video src={resultVideo} controls className="rounded-lg shadow-[0_0_30px_rgba(220,38,38,0.2)] w-full max-h-[500px]" />
              </div>
            )}

            {!loading && searchResult && (
              <div className="w-full animate-in slide-in-from-bottom duration-500 overflow-y-auto max-h-[500px] space-y-6 scrollbar-hide">
                <div className="prose prose-invert max-w-none text-gray-300 leading-relaxed font-light">
                  {searchResult.text}
                </div>
                {searchResult.sources.length > 0 && (
                  <div className="pt-6 border-t border-zinc-900">
                    <h4 className="text-[10px] font-bold text-red-500 mb-3 uppercase tracking-[0.2em]">Fontes Externas:</h4>
                    <div className="flex flex-wrap gap-2">
                      {searchResult.sources.map((source, i) => (
                        <a 
                          key={i} 
                          href={source.uri} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[10px] bg-zinc-900 hover:bg-red-900/40 text-gray-500 hover:text-red-400 px-3 py-2 rounded-md transition-colors border border-zinc-800 flex items-center gap-2 uppercase font-bold tracking-widest"
                        >
                          {source.title || 'Link'}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
