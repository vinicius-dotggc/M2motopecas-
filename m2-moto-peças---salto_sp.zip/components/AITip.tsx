
import React, { useState, useEffect } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const AITip: React.FC = () => {
  const [tip, setTip] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTip = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: "Gere uma dica técnica de manutenção de moto muito curta (máximo 150 caracteres) para um motociclista. Seja técnico e útil. Exemplo: 'Verifique a folga da corrente a cada 500km'.",
        });
        setTip(response.text || null);
      } catch (e) {
        console.error("Erro ao carregar dica IA", e);
        setTip("Dica M2: Mantenha seus pneus sempre calibrados para maior vida útil e segurança.");
      } finally {
        setLoading(false);
      }
    };
    fetchTip();
  }, []);

  return (
    <div className="bg-gradient-to-r from-red-950/40 to-transparent border-l-4 border-red-600 p-4 rounded-r-2xl mb-12 animate-in slide-in-from-left duration-700">
      <div className="flex items-center gap-3 mb-1">
        <Sparkles className="text-red-500" size={16} />
        <span className="text-[10px] font-bold text-red-500 uppercase tracking-[0.3em]">Dica Técnica IA</span>
      </div>
      {loading ? (
        <div className="flex items-center gap-2">
          <Loader2 className="animate-spin text-zinc-700" size={14} />
          <div className="h-4 w-48 bg-zinc-800 rounded animate-pulse"></div>
        </div>
      ) : (
        <p className="text-sm text-gray-300 font-light italic">"{tip}"</p>
      )}
    </div>
  );
};
